setwd("C:/Users/MSI/OneDrive/Desktop/IT24102565ps5")
getwd()
delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(delivery_times)

breaks <- seq(20, 70, length.out = 10)
##rename
names(delivery_times) <- "Delivery_Time"
hist(delivery_times$Delivery_Time,
     breaks = breaks,
     right = FALSE,
     col = "lightblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     border = "black")



names(delivery_times) <- "Delivery_Time"
breaks <- seq(20, 70, length.out = 10)
hist_data <- hist(delivery_times$Delivery_Time,
                  breaks = breaks,
                  right = FALSE,
                  plot = FALSE)
cum_freq <- cumsum(hist_data$counts)

class_boundaries <- hist_data$breaks

cum_points <- c(0, cum_freq)

plot(class_boundaries, cum_points, type = "o",
     col = "blue", pch = 16,
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")





