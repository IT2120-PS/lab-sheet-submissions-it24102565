setwd("C:\\Users\\MSI\\OneDrive\\Desktop\\it24102565")
getwd()

lower <- 0
upper <- 40
a <- 10
b <- 25
prob1 <- (b - a) / (upper - lower)
prob1

lambda <- 1/3
prob2 <- pexp(2, rate = lambda)
prob2

mean <- 100
sd <- 15
prob3_i <- 1 - pnorm(130, mean, sd)
prob3_i

iq_95 <- qnorm(0.95, mean, sd)
iq_95
