setwd("C:\\Users\\MSI\\OneDrive\\Desktop")
getwd()

#Random variables x has binomial distribution
#X∼Binomial(n=50,p=0.85).

1 - pbinom(46, 50, 0.85)

#Number of colls in an hour

#Here, rondom variables x has poisson distribution with lambda = 12
#X∼Poisson(λ=12)

dpois(15, 12)

