##part 1
setwd("C:\\Users\\IT24102565\\Desktop\\IT24102565")

branch_data <- read.table("Exercise.txt", header=TRUE, sep = ",")
fix(branch_data)
attach(branch_data)

##part 2
sapply(branch_data, typeof)

##part 3
boxplot(Sales_X1,main="Box plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE)

##part 4
summary(Advertising_X2)

IQR(Advertising_X2)

##part 5
get_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper bound = ", ub))
  print(paste("Lower bound = ", lb))
  print(paste("Outliers:",paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

get_outliers(Years_X3)
